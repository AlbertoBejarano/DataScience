```python
#https://datavizpyr.com/add-regression-line-per-group-with-seaborn-in-python/
```


```python
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
```


```python
penguins_data="https://raw.githubusercontent.com/datavizpyr/data/master/palmer_penguin_species.tsv"
```


```python
penguins_df = pd.read_csv(penguins_data, sep="\t")
penguins_df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>species</th>
      <th>island</th>
      <th>culmen_length_mm</th>
      <th>culmen_depth_mm</th>
      <th>flipper_length_mm</th>
      <th>body_mass_g</th>
      <th>sex</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Adelie</td>
      <td>Torgersen</td>
      <td>39.1</td>
      <td>18.7</td>
      <td>181.0</td>
      <td>3750.0</td>
      <td>MALE</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Adelie</td>
      <td>Torgersen</td>
      <td>39.5</td>
      <td>17.4</td>
      <td>186.0</td>
      <td>3800.0</td>
      <td>FEMALE</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Adelie</td>
      <td>Torgersen</td>
      <td>40.3</td>
      <td>18.0</td>
      <td>195.0</td>
      <td>3250.0</td>
      <td>FEMALE</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Adelie</td>
      <td>Torgersen</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Adelie</td>
      <td>Torgersen</td>
      <td>36.7</td>
      <td>19.3</td>
      <td>193.0</td>
      <td>3450.0</td>
      <td>FEMALE</td>
    </tr>
  </tbody>
</table>
</div>




```python
# add regression line with lmplot()
sns.lmplot(x="culmen_length_mm", 
           y="flipper_length_mm", 
           data=penguins_df,
           height=10)
plt.xlabel("Culmen Length (mm)")
plt.ylabel("Flipper Length (mm)")
plt.savefig("How_To_Add_Regression_Line_in_Seaborn_with_lmplot.png",
                    format='png',dpi=150)
```


    
![png](output_4_0.png)
    



```python
# add regression line with regplot()
plt.figure(figsize=(10,8))
sns.regplot(x="culmen_length_mm", 
           y="flipper_length_mm", 
           data=penguins_df)
plt.xlabel("Culmen Length (mm)")
plt.ylabel("Flipper Length (mm)")
plt.savefig("How_To_Add_Regression_Line_in_Seaborn_with_regplot.png",
                    format='png',dpi=150)
```


    
![png](output_5_0.png)
    



```python
# add regression line per group Seaborn
sns.lmplot(x="culmen_length_mm", 
           y="flipper_length_mm", 
           hue="species",
           data=penguins_df,
           height=10)
plt.xlabel("Culmen Length (mm)")
plt.ylabel("Flipper Length (mm)")
plt.savefig("How_To_Add_Regression_Line_per_group_Seaborn.png",
                    format='png',dpi=150)
```


    
![png](output_6_0.png)
    



```python

```


```python

```
